package com.shiyar.internetaccounts;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Typeface;
import android.content.ContentValues;
import android.database.Cursor;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    Db db;
    LinearLayout root, content, nav;
    final int pad = 16;
    int textColor = 0xFF172B4D;
    int blue = 0xFF1E4E79;
    int green = 0xFF237A57;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new Db(this);
        showHome();
    }

    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(textColor); t.setGravity(Gravity.RIGHT);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(4, 8, 4, 8); return t;
    }
    EditText field(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint);
        e.setTextSize(16); e.setPadding(12, 8, 12, 8); return e;
    }
    Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setOnClickListener(v -> action.run()); return b;
    }
    void begin(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(0xFFF5F7FA);
        TextView heading = text(title, 22, true); heading.setTextColor(0xFFFFFFFF);
        heading.setBackgroundColor(blue); heading.setPadding(pad, 18, pad, 18);
        root.addView(heading, new LinearLayout.LayoutParams(-1, -2));
        nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        addNav("الرئيسية", this::showHome);
        addNav("الزبائن", this::showCustomers);
        addNav("القرى", this::showVillages);
        addNav("الدفعات", this::showPayments);
        root.addView(nav);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(pad, pad, pad, 28); content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }
    void addNav(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setTextSize(12); b.setAllCaps(false);
        nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        b.setOnClickListener(v -> r.run());
    }
    void addFieldLabel(String label, EditText e) {
        content.addView(text(label, 14, true));
        content.addView(e, new LinearLayout.LayoutParams(-1, -2));
    }
    void message(String s) { new AlertDialog.Builder(this).setMessage(s).setPositiveButton("حسناً", null).show(); }
    double number(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim().replace(",", ".")); }
        catch(Exception ex) { return 0; }
    }
    long longNumber(EditText e) {
        try { return Long.parseLong(e.getText().toString().trim()); } catch(Exception ex) { return -1; }
    }
    void showHome() {
        begin("حسابات الإنترنت");
        content.addView(text("ملخص العمل", 20, true));
        content.addView(text("عدد الزبائن: " + db.customerCount(), 18, true));
        content.addView(text("عدد القرى: " + db.villageCount(), 18, true));
        content.addView(text(String.format(Locale.US, "المقبوضات المسجلة: $%.2f", db.totalPayments()), 18, true));
        content.addView(text(String.format(Locale.US, "الاشتراكات الشهرية المتوقعة: $%.2f", db.monthlyDue()), 18, true));
        content.addView(text("تعمل قاعدة البيانات محلياً على الهاتف، ولا تحتاج إلى اتصال بالإنترنت بعد تثبيت التطبيق.", 15, false));
        content.addView(button("إضافة زبون جديد", this::showAddCustomer));
        content.addView(button("تسجيل دفعة جديدة", this::showAddPayment));
        content.addView(button("تصدير نسخة احتياطية", this::exportBackup));
    }
    void showVillages() {
        begin("القرى");
        EditText name = field("اسم القرية");
        addFieldLabel("إضافة قرية", name);
        content.addView(button("حفظ القرية", () -> {
            String n=name.getText().toString().trim();
            if(n.isEmpty()){message("اكتب اسم القرية.");return;}
            try { db.addVillage(n); message("تم حفظ القرية."); showVillages(); }
            catch(Exception e){message("هذه القرية موجودة مسبقاً أو تعذر حفظها.");}
        }));
        content.addView(text("القرى المسجلة", 18, true));
        Cursor c=db.villages();
        while(c.moveToNext()) content.addView(text(c.getLong(0)+" - "+c.getString(1),16,false));
        c.close();
    }
    void showCustomers() {
        begin("الزبائن");
        EditText search=field("بحث بالاسم أو الهاتف أو رقم الزبون");
        content.addView(search);
        content.addView(button("بحث", () -> listCustomers(search.getText().toString())));
        content.addView(button("إضافة زبون", this::showAddCustomer));
        listCustomers("");
    }
    void listCustomers(String q) {
        // Preserve current screen; append list below existing controls.
        Cursor c=db.customers(q);
        content.addView(text("النتائج",18,true));
        int count=0;
        while(c.moveToNext() && count<500) {
            long id=c.getLong(0); String name=c.getString(1), village=c.getString(2), phone=c.getString(3);
            double fee=c.getDouble(4);
            content.addView(button("#"+id+"  "+name+" — "+village+" — $"+String.format(Locale.US,"%.2f",fee),
                () -> showCustomerDetail(id)));
            count++;
        }
        c.close();
        if(count==0) content.addView(text("لا توجد نتائج.",15,false));
    }
    void showAddCustomer() {
        begin("إضافة زبون");
        EditText name=field("اسم الزبون");
        EditText village=field("رقم القرية (من شاشة القرى)");
        EditText phone=field("رقم الهاتف");
        EditText fee=field("الاشتراك الشهري بالدولار");
        addFieldLabel("اسم الزبون",name); addFieldLabel("رقم القرية",village);
        addFieldLabel("الهاتف",phone); addFieldLabel("الاشتراك الشهري ($)",fee);
        content.addView(text("أضف القرية أولاً من شاشة القرى. رقم القرية هو الرقم الظاهر بجانب اسمها.",13,false));
        content.addView(button("حفظ الزبون", () -> {
            String n=name.getText().toString().trim();
            if(n.isEmpty() || number(fee)<0){message("أدخل اسم الزبون والاشتراك.");return;}
            long vid=longNumber(village);
            if(vid<1) vid=-1;
            long id=db.addCustomer(n,vid,phone.getText().toString(),number(fee));
            if(id>0){message("تم حفظ الزبون. رقمه: "+id);showCustomers();}
            else message("تعذر حفظ الزبون.");
        }));
    }
    void showCustomerDetail(long id) {
        begin("حساب الزبون");
        Cursor c=db.customerById(id);
        if(!c.moveToFirst()){c.close();message("الزبون غير موجود.");return;}
        String name=c.getString(1); double fee=c.getDouble(2); c.close();
        content.addView(text("رقم الزبون: "+id,16,true));
        content.addView(text("الاسم: "+name,20,true));
        content.addView(text(String.format(Locale.US,"الاشتراك الشهري: $%.2f",fee),16,false));
        content.addView(text("حساب الأشهر",18,true));
        for(int m=1;m<=12;m++){
            double paid=db.allocated(id,m); double rem=Math.max(0,fee-paid);
            content.addView(text(String.format(Locale.US,"شهر %d: مدفوع $%.2f | متبقٍ $%.2f",m,paid,rem),15,false));
        }
        content.addView(button("تسجيل دفعة لهذا الزبون", () -> showAddPaymentFor(id)));
    }
    void showPayments() {
        begin("سجل الدفعات");
        content.addView(button("تسجيل دفعة جديدة", this::showAddPayment));
        Cursor c=db.payments();
        while(c.moveToNext()){
            String line=String.format(Locale.US,"#%d | %s | %s | $%.2f | موزع $%.2f",
                c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getDouble(4));
            content.addView(text(line,14,false));
        }
        c.close();
    }
    void showAddPayment() { showAddPaymentFor(-1); }
    void showAddPaymentFor(long preselected) {
        begin("تسجيل دفعة");
        EditText date=field("تاريخ القبض YYYY-MM-DD");
        date.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));
        EditText customer=field("رقم الزبون");
        if(preselected>0) customer.setText(String.valueOf(preselected));
        EditText amount=field("المبلغ المقبوض كاملاً ($)");
        EditText[] months=new EditText[12];
        addFieldLabel("تاريخ القبض",date); addFieldLabel("رقم الزبون",customer);
        addFieldLabel("المبلغ المقبوض كاملاً بالدولار",amount);
        content.addView(text("وزّع المبلغ على الأشهر التي يغطيها. يجب أن يساوي مجموعها مبلغ القبض.",14,true));
        for(int i=0;i<12;i++){
            months[i]=field("مبلغ مخصص لشهر "+(i+1));
            addFieldLabel("الشهر "+(i+1)+" ($)",months[i]);
        }
        EditText note=field("ملاحظة اختيارية"); addFieldLabel("ملاحظات",note);
        content.addView(button("حفظ الدفعة", () -> {
            long cid=longNumber(customer); double total=number(amount);
            if(cid<1 || total<=0 || date.getText().toString().trim().isEmpty()){
                message("تحقق من رقم الزبون والتاريخ والمبلغ.");return;
            }
            Cursor check=db.customerById(cid);
            boolean exists=check.moveToFirst(); check.close();
            if(!exists){message("رقم الزبون غير موجود.");return;}
            double[] alloc=new double[12]; double sum=0;
            for(int i=0;i<12;i++){alloc[i]=number(months[i]); if(alloc[i]<0){message("لا تستخدم مبالغ سالبة.");return;} sum+=alloc[i];}
            if(Math.abs(sum-total)>0.009){
                message(String.format(Locale.US,"مجموع توزيع الأشهر هو $%.2f بينما مبلغ القبض $%.2f. صحح التوزيع.",sum,total));return;
            }
            long id=db.addPayment(date.getText().toString().trim(),cid,total,alloc,note.getText().toString());
            if(id>0){message("تم حفظ الدفعة بنجاح.");showPayments();}
            else message("تعذر حفظ الدفعة. تحقق من البيانات.");
        }));
    }
    void exportBackup() {
        // Uses Android's create-document picker; the SQLite database is copied to chosen location.
        try {
            android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
            intent.setType("application/octet-stream");
            intent.putExtra(android.content.Intent.EXTRA_TITLE, "internet_accounts_backup.db");
            startActivityForResult(intent, 77);
        } catch(Exception e) { message("تعذر فتح نافذة حفظ النسخة الاحتياطية."); }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==77 && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            try {
                java.io.InputStream in = new java.io.FileInputStream(getDatabasePath("internet_accounts.db"));
                java.io.OutputStream out = getContentResolver().openOutputStream(data.getData());
                byte[] buf=new byte[8192]; int n;
                while((n=in.read(buf))>0) out.write(buf,0,n);
                out.close(); in.close(); message("تم تصدير النسخة الاحتياطية.");
            } catch(Exception e) { message("فشل التصدير. حاول اختيار مكان آخر."); }
        }
    }
}
