package com.shiyar.internetaccounts;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Db extends SQLiteOpenHelper {
    public Db(Context c) { super(c, "internet_accounts.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE villages(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)");
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, village_id INTEGER, phone TEXT, fee REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, paid_at TEXT NOT NULL, customer_id INTEGER NOT NULL, amount REAL NOT NULL, note TEXT)");
        db.execSQL("CREATE TABLE allocations(id INTEGER PRIMARY KEY AUTOINCREMENT, payment_id INTEGER NOT NULL, month INTEGER NOT NULL, amount REAL NOT NULL)");
        db.execSQL("CREATE INDEX idx_customer_village ON customers(village_id)");
        db.execSQL("CREATE INDEX idx_payment_customer ON payments(customer_id)");
        db.execSQL("CREATE INDEX idx_alloc_payment ON allocations(payment_id)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    public long addVillage(String name) {
        ContentValues v = new ContentValues(); v.put("name", name.trim());
        return getWritableDatabase().insertOrThrow("villages", null, v);
    }

    public long addCustomer(String name, long villageId, String phone, double fee) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim()); v.put("village_id", villageId);
        v.put("phone", phone.trim()); v.put("fee", fee);
        return getWritableDatabase().insert("customers", null, v);
    }

    public long addPayment(String date, long customerId, double amount, double[] months, String note) {
        double sum = 0;
        for (double m : months) sum += m;
        if (Math.abs(sum - amount) > 0.009) return -2;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        long paymentId = -1;
        try {
            ContentValues p = new ContentValues();
            p.put("paid_at", date); p.put("customer_id", customerId);
            p.put("amount", amount); p.put("note", note);
            paymentId = db.insertOrThrow("payments", null, p);
            for (int i = 0; i < months.length; i++) {
                if (months[i] > 0) {
                    ContentValues a = new ContentValues();
                    a.put("payment_id", paymentId); a.put("month", i + 1); a.put("amount", months[i]);
                    db.insertOrThrow("allocations", null, a);
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            paymentId = -1;
        } finally { db.endTransaction(); }
        return paymentId;
    }

    public Cursor villages() {
        return getReadableDatabase().rawQuery("SELECT id,name FROM villages ORDER BY name", null);
    }

    public Cursor customers(String search) {
        String q = "%" + search.trim() + "%";
        return getReadableDatabase().rawQuery(
            "SELECT c.id,c.name,COALESCE(v.name,'بدون قرية'),c.phone,c.fee " +
            "FROM customers c LEFT JOIN villages v ON v.id=c.village_id " +
            "WHERE c.name LIKE ? OR c.phone LIKE ? OR CAST(c.id AS TEXT) LIKE ? ORDER BY c.name",
            new String[]{q,q,q});
    }

    public Cursor customerById(long id) {
        return getReadableDatabase().rawQuery("SELECT id,name,fee FROM customers WHERE id=?", new String[]{String.valueOf(id)});
    }

    public Cursor payments() {
        return getReadableDatabase().rawQuery(
            "SELECT p.id,p.paid_at,c.name,p.amount, " +
            "COALESCE((SELECT SUM(a.amount) FROM allocations a WHERE a.payment_id=p.id),0),p.note " +
            "FROM payments p JOIN customers c ON c.id=p.customer_id ORDER BY p.id DESC LIMIT 500", null);
    }

    public double allocated(long customerId, int month) {
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT COALESCE(SUM(a.amount),0) FROM allocations a JOIN payments p ON p.id=a.payment_id WHERE p.customer_id=? AND a.month=?",
            new String[]{String.valueOf(customerId), String.valueOf(month)});
        double result = 0; if (c.moveToFirst()) result = c.getDouble(0); c.close(); return result;
    }

    public double totalPayments() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments", null);
        double x=0; if(c.moveToFirst()) x=c.getDouble(0); c.close(); return x;
    }
    public int customerCount() {
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM customers",null);
        int x=0; if(c.moveToFirst()) x=c.getInt(0); c.close(); return x;
    }
    public int villageCount() {
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM villages",null);
        int x=0; if(c.moveToFirst()) x=c.getInt(0); c.close(); return x;
    }
    public double monthlyDue() {
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(fee),0) FROM customers WHERE active=1",null);
        double x=0; if(c.moveToFirst()) x=c.getDouble(0); c.close(); return x;
    }
    public double outstanding() {
        Cursor c=getReadableDatabase().rawQuery(
            "SELECT COALESCE(SUM(MAX(0,c.fee - COALESCE((SELECT SUM(a.amount) FROM allocations a JOIN payments p ON p.id=a.payment_id WHERE p.customer_id=c.id AND a.month=CAST(strftime('%m','now') AS INTEGER)),0))),0) FROM customers c WHERE c.active=1", null);
        double x=0; if(c.moveToFirst()) x=c.getDouble(0); c.close(); return x;
    }
}
