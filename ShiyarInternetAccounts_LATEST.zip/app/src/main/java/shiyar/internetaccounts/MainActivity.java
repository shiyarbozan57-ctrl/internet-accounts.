package shiyar.internetaccounts;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Environment;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
 private WebView web; private ValueCallback<Uri[]> fileCallback; private static final int PICK_FILE=77;
 @Override public void onCreate(Bundle state){super.onCreate(state); web=new WebView(this);
  web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true);
  web.addJavascriptInterface(new Object(){@JavascriptInterface public void saveBackup(String json){runOnUiThread(()->{try{
   ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,"نسخة-حسابات-الانترنت.json"); v.put(MediaStore.Downloads.MIME_TYPE,"application/json"); v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);
   Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u==null)throw new Exception(); OutputStream o=getContentResolver().openOutputStream(u); o.write(json.getBytes("UTF-8")); o.close(); Toast.makeText(MainActivity.this,"تم حفظ النسخة في التنزيلات",Toast.LENGTH_LONG).show();
  }catch(Exception e){Toast.makeText(MainActivity.this,"تعذر حفظ النسخة",Toast.LENGTH_LONG).show();}});}},"AndroidBridge");
  web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams p){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(i,"اختر ملف النسخة الاحتياطية"),PICK_FILE);return true;}});
  setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK_FILE&&fileCallback!=null){Uri[] a=c==RESULT_OK&&d!=null&&d.getData()!=null?new Uri[]{d.getData()}:null;fileCallback.onReceiveValue(a);fileCallback=null;}}
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
